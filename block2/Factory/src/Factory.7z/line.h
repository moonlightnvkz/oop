//
// Created by moonlightnvkz on 13.02.17.
//

#pragma once

#include "point.h"

struct Line {
    const struct Point from;
    const struct Point to;
};

extern const void *Line;