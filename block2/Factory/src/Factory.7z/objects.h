//
// Created by moonlightnvkz on 18.02.17.
//

#pragma once

#include "point.h"
#include "circle.h"
#include "rect.h"
#include "line.h"