//
// Created by moonlightnvkz on 13.02.17.
//

#pragma once

#include "point.h"

struct Rect {
    const struct Point position;
    const struct Point dimensions;
};

extern const void *Rect;